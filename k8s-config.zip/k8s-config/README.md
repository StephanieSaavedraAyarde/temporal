# Ansible k8s-config

## Requerimientos

- Ansible 4.8+
    - requirements.txt
- VM bastion debe tener instalado: 
    - helm
    - kubectl 
- Cluster k8s
    - metal-lb
        - con rango de ip para ingress Kong
    - core dns
- Server Vault
    - token con privilegios
- Server Postgres
    - 9.6 para Konga
    - 11+ para Kong
    - usuarios con privilegios root
    
## Instalar
Instalar requerimientos python Ansible
```sh
./install_req.sh
```

Activar entorno virtual de python

```sh
source ./.virtualenv_python3/bin/activate
```

Instalar requerimientos ansible galaxy

```sh
ansible-galaxy collection install -r requirements.yml
```

## Ejecutar 

Configurar el archivo inventory 

Ejecutar:
    
    ansible-playbook main.yml --extra-vars "vars_file=vars/k8s.yml"