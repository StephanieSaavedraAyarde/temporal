#!/bin/bash
echo "Antes de usar verifique: "
echo "sudo apt install virtualenv "
echo
echo "Ejemplos de uso:"
echo
echo "./install_req.sh"
echo "./install_req.sh requerimiento_nombre_personalizado.txt"
echo "./install_req.sh requerimiento.txt python2"
echo
py=${2:-python3}
echo "version de python: /usr/bin/$py"
echo
/usr/bin/$py --version
echo
path_python="./.virtualenv_$py"
echo "Ruta por defecto: $path_python"
echo
echo "Limpiando $path_python"
echo
echo "		rm -Rf $path_python"
echo
rm -Rf $path_python
echo "Creando virtualenv"
echo
virtualenv -q -p /usr/bin/$py $path_python
# source $path_python/bin/activate
req=${1:-requirements.txt}
echo "Instalando $req"
echo
echo
$path_python/bin/pip install -r $req
# pip install -r requirements.txt
echo
echo
echo
echo "Para activar ejecute:"
echo
echo "		source $path_python/bin/activate"
echo
echo
echo "Para desactivar ejecute:"
echo
echo "		deactivate"
echo
echo